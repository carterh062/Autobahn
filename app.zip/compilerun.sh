rm app.zip
zip -r app.zip .
nw app.zip
